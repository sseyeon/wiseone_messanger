APNS TEST
-telnet gateway.push.apple.com 2195


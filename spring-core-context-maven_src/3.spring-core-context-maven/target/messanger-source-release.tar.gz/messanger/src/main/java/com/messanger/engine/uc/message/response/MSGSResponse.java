package com.messanger.engine.uc.message.response;

import com.messanger.engine.uc.message.MessageResponse;

public class MSGSResponse extends MessageResponse {

    public MSGSResponse(String type) {
        super(type);
    }

}

package com.messanger.engine.uc.message.response;

import com.messanger.engine.uc.message.MessageResponse;

public class GRPSResponse extends MessageResponse {

	public GRPSResponse(String type) {
		super(type);
	}
}

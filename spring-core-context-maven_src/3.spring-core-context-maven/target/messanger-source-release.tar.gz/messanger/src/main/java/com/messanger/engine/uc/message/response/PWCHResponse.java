package com.messanger.engine.uc.message.response;

import com.messanger.engine.uc.message.MessageResponse;

public class PWCHResponse extends MessageResponse {

    public PWCHResponse(String type) {
        super(type);
    }
}

package com.messanger.engine.uc.message.request;

import com.messanger.engine.uc.message.MessageRequest;

public class ALCKRequest extends MessageRequest {

    /**
     * 
     * @param type
     */
    public ALCKRequest(String type) {
        super(type);
    }

}

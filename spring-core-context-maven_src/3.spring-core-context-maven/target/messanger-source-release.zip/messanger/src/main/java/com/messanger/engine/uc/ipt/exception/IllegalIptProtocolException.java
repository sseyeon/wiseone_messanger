package com.messanger.engine.uc.ipt.exception;

public class IllegalIptProtocolException extends Exception {

	private static final long serialVersionUID = 4946901691444360085L;
	
	public IllegalIptProtocolException(String message) {
		super(message);
	}
}

package com.messanger.engine.uc.utils;

public class Const {
	//기본값
	public static final String ENC_KEY = "SST.ECP.20140331";
}

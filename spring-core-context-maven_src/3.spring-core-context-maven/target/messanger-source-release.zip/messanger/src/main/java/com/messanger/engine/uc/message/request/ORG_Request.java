package com.messanger.engine.uc.message.request;

import com.messanger.engine.uc.message.MessageRequest;

public class ORG_Request extends MessageRequest {
    public ORG_Request(String type) {
        super(type);
    }
}

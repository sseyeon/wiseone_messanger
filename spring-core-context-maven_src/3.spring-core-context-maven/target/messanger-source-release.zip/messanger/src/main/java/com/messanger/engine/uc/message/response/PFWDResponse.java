package com.messanger.engine.uc.message.response;

import com.messanger.engine.uc.message.MessageResponse;

public class PFWDResponse extends MessageResponse {

	public PFWDResponse(String type) {
		super(type);
	}	
}

package com.messanger.engine.uc.message.response;

import com.messanger.engine.uc.message.MessageResponse;

public class PDISResponse extends MessageResponse {

	public PDISResponse(String type) {
		super(type);
	}
}

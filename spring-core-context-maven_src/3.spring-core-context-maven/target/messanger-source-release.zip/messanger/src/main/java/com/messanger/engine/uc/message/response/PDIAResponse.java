package com.messanger.engine.uc.message.response;

import com.messanger.engine.uc.message.MessageResponse;

public class PDIAResponse extends MessageResponse {

	public PDIAResponse(String type) {
		super(type);
	}
}
